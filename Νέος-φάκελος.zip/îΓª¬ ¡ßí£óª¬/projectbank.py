from os.path import join, dirname
from watson_developer_cloud import TextToSpeechV1
from watson_developer_cloud import SpeechToTextV1
import json
import http.client
def payment():
    

    conn = http.client.HTTPSConnection("apis.nbg.gr")

   # payload = "{\"to\":{\"counterparty_id\":\"8bf02f69-6150-41a8-a1b1-fda9fa398cc7\"},\"charge_policy\":\"SHARED\",\"value\":{\"currency\":\"EUR\",\"amount\":\"50\"},\"description\":\"Jasucfo ziumajep maciz la feibje kot va jo fo paowsu nigawtop daf vajebtil.\"}"
    with open("C:\Users\GMG\Desktop\Project\Example\HELPME.txt") as f:
        content = f.readlines()
    # you may also want to remove whitespace characters like `\n` at the end of each line
    content = [x.strip() for x in content]
    print content
    print len(content)


#conn.request("POST", "/public/nbgapis/obp/v3.0.1/banks/DB173089-A8FE-43F1-8947-F1B2A8699829/accounts/54faf236-0831-4eab-a180-994163459ceb/owner/transaction-request-types/counterparty/transaction-requests", payload, headers)

#res = conn.getresponse()
#data = res.read()

#print(data.decode("utf-8"))
def TTS():
    text_to_speech = TextToSpeechV1(
    username='83488eaa-633a-4c70-91d0-4e26104af4b9',
    password='GYUxYqJ36kk4',
    x_watson_learning_opt_out=False)  # Optional flag
    print(json.dumps(text_to_speech.voices(), indent=2))
    with open(join(dirname(__file__), 'C:\Users\GMG\Desktop\Project\Example\output.wav'), 'wb') as audio_file:
       audio_file.write(text_to_speech.synthesize('Hello world!', accept='audio/wav', voice="en-US_AllisonVoice"))
    with open(join(dirname(__file__), 'output.wav'),
                  'wb') as audio_file:    audio_file.write(text_to_speech.synthesize('Hello world!', accept='audio/wav',
                                           voice = "en-US_AllisonVoice"))
    print(json.dumps(text_to_speech.pronunciation('Watson', pronunciation_format='spr'), indent=2))
    print(json.dumps(text_to_speech.customizations(), indent=2))
def STT():

    speech_to_text = SpeechToTextV1(
    username='09419423-ef4c-41e9-a702-d4b7cd05e3eb',
    password='Y0k6sYK7654K'
    )

    print (json.dumps(speech_to_text.get_model('en-US_BroadbandModel'), indent=2))

    with open(join(dirname(__file__), 'C:\Users\GMG\Desktop\Project\Example\output.wav'), 'rb') as audio_file:
        x=(json.dumps(speech_to_text.recognize(
        audio_file, content_type = 'audio/wav', timestamps = True),indent = 2)).split()
        print x
        strList = []
        str = "\"transcript\":"
        label = False
        count = 0

        for i in x:

            if (label):
                if i.find("\"") != -1:
                    count += 1
                    i.replace("\"", "")
                    strList.append(i)
                    if count == 2:
                        label = False
                else:
                    strList.append(i)

            if str==i:
                label=True

        print strList
payment()