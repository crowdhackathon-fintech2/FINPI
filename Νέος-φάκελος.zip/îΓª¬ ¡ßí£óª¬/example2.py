import http.client

conn = http.client.HTTPSConnection("apis.nbg.gr")

payload = "{\"to\":{\"counterparty_id\":\"8bf02f69-6150-41a8-a1b1-fda9fa398cc7\"},\"charge_policy\":\"SHARED\",\"value\":{\"currency\":\"EUR\",\"amount\":\"50\"},\"description\":\"Jasucfo ziumajep maciz la feibje kot va jo fo paowsu nigawtop daf vajebtil.\"}"

headers = {
    'content-type': "text/json",
    'accept': "text/json",
    'sandbox_id': "Anupam",
    'application_id': "REPLACE_THIS_VALUE",
    'user_id': "9d7f2ef4-7262-4429-a487-7979e4a76447",
    'username': "User1",
    'provider_id': "NBG.gr",
    'provider': "NBG"
    }

conn.request("POST", "/public/nbgapis/obp/v3.0.1/banks/DB173089-A8FE-43F1-8947-F1B2A8699829/accounts/54faf236-0831-4eab-a180-994163459ceb/owner/transaction-request-types/counterparty/transaction-requests", payload, headers)

res = conn.getresponse()
data = res.read()
print(data[data.find("amount",0)+8]+data[data.find("amount",0)+9]+data[data.find("amount",0)+10]+data[data.find("amount",0)+11]+" EUR")


#print(data.decode("utf-8"))